﻿using stanclova_to_do.MVVM;
using stanclova_to_do.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stanclova_to_do.ViewModel
{
    internal class MainWindowViewModel : ViewModelBase
    {
        public ObservableCollection<Quest> Quests { get; } 

        
        // Tento řádek vytváří příkaz pro tlačítko „Přidat“
        // RelayCommand říká: "když někdo klikne, zavolej tuto metodu"
        // execute => AddItem() znamená: ignorujeme parametr (exekuce), jen zavoláme metodu AddItem()
        public RelayCommand AddCommand => new RelayCommand(execute => AddTask());

        // Tento řádek vytváří příkaz pro tlačítko „Smazat“
        // Tlačítko se spustí jen tehdy, pokud je vybraná nějaká položka (SelectedItem != null)
        // execute => DeleteItem() říká, co se má stát po kliknutí
        // canExecute => SelectedItem != null říká, zda je tlačítko aktivní
        public RelayCommand DeleteCommand => new RelayCommand(execute => DeleteTask(), canExecute => SelectedTask != null);

        // '=>' je jen zkrácený zápis pro malou funkci / metodu, kterou předáváme jako parametr.
        

        private Quest selectedTask;
        public Quest SelectedTask
        {
            get { return selectedTask; }
            set
            {
                selectedTask = value;
                OnPropertyChanged();
            }
        }

        public MainWindowViewModel()
        {
            Quests = new ObservableCollection<Quest>();
        }

        //ted si udelam pomocne promenne abych si do nich ukladala co uživatel napise a do pak vkladala do questu, který budu pridavat
        private string newName; //interně si skladuji hodnoty
        public string NewName //sem vidí binding - textbox, datepicker, ...
        {
            get => newName; //kam to uloží - "co se vrátí" ... vrátím to newName
            set //co se uloží
            {
                newName = value;
                OnPropertyChanged(); //zavolání funkce aby se vedelo, že se zmenilo to, co je v textboxu
            }
        }

        private DateTime? newDate;
        public DateTime? NewDate
        {
            get => newDate;
            set
            {
                newDate = value;
                OnPropertyChanged();
            }
        }

        //přidání tasků - nastavím to na dané hodnoty (vytvořím nový objekt typu task do kolekce tasků)
        private void AddTask()
        {
            if (string.IsNullOrWhiteSpace(NewName))
            {
                return;
            }

            var quest = new Quest
            {
                Name = NewName,  
                Date = NewDate
            };

            Quests.Add(quest);

            newName = "";
            NewDate = null; 

        }

        //odeberu task z te kolekce tasků
        private void DeleteTask()
        {
            if (SelectedTask != null)
            {
                Quests.Remove(SelectedTask);
            }
        }
    }
}