﻿using System.Runtime.InteropServices.Marshalling;

namespace stanclova_pisemna_prace
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }

    class Kun
    {
        int[,] sachovnice = new int[8, 8];
        
        List<int> pozice_prekazek_X = new List<int>();
        List<int> pozice_prekazek_Y = new List<int>();

        List<int> navstivene_X = new List<int>();
        List<int> navstivene_Y = new List<int>();

        Queue<int[]> mozne_pole = new Queue<int[]>();

        public int[] start_pozice = [0, 0];
        public int[] cil_pozice = [0, 0];

        int pocet_vetvi = 0;

        int pocet_kroku = 0;
        int pocet_kroku_vetev = 0;

        public int[,] vektor_tahu = new int[,] { { -2, 1 }, { -2, 1 }, { 2, 1 }, { 2, -1 }, { 1, -2 }, { -1, -2 }, { 1, 2 }, { -1, 2 } };

        public void NaplneniSachovnice()
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    sachovnice[i, j] = int.MaxValue;
                }
            }
        }

        public void NacteniSachovnice(string soubor)
        {
            using (StreamReader sr = new StreamReader())
            {
                string prvni_radek = sr.ReadLine();
                int pocet_prekazek = int.Parse(prvni_radek);

                for (int i = 0; i < pocet_prekazek; i++)
                {
                    string radek = sr.ReadLine();
                    string[] radek_data = radek.Split(" ");

                    int dataX = int.Parse(radek_data[0]);
                    pozice_prekazek_X.Add(dataX);

                    int dataY = int.Parse(radek_data[1]);
                    pozice_prekazek_X.Add(dataY);
                }

                string[] start_pozice_radek = sr.ReadLine().Split(" ");
                start_pozice[0] = int.Parse(start_pozice_radek[0]);
                start_pozice[1] = int.Parse(start_pozice_radek[1]);

                string cil_pozice_radek = sr.ReadLine();
                cil_pozice[0] = int.Parse(start_pozice_radek[0]);
                cil_pozice[1] = int.Parse(start_pozice_radek[1]);
            }
        }


        /// <summary>
        /// Pokud bude tah, který chci provést platný a na pozici nebude překážka - vrátí to true; v opačném případě false
        /// </summary>
        /// <param name="aktualni_pozice"></param>
        /// <returns></returns>
        public bool OverPole(int[] aktualni_pozice)
        {
            for (int i = 0; i < pozice_prekazek_X.Count(); i++)
            {
                int X = aktualni_pozice[0];
                int Y = aktualni_pozice[1];
                if (X > -1 && X < 9 && Y > -1 && Y < 9 && X == pozice_prekazek_X[0] && Y == pozice_prekazek_Y[1]) //aktualni pozice neutíká mimo hrací pole (0 až 8) a není tam překážka
                {
                    return false; //neplatný tah, je tam překážka
                }
            }
            return true; //žádná překážka, platný tah
        }

        public bool Navstiveno(int[] aktualni_pozice)
        {
            for (int i = 0; i < navstivene_X.Count; i++)
            {
                if (aktualni_pozice[0] == navstivene_X[i] && aktualni_pozice[1] == navstivene_Y[i]) 
                { 
                    return true; 
                }
            }
            return false;
        }


        //snaha o prohledavani do sirkz --- CHYBÍ: musela bych zreakonstruovat pak cestu pomocí šachovnice, kde bych ukladala hodnoty nejmensi jak jsem se ze staartu na pole dostala - zrekonstruovala bych to asi pomocí znovu pruchodu jako kun ale jen na nejmensi cisla na poli
        public void Tahni(int[] aktualni_pozice)
        {
            while (true)
            {
                if (aktualni_pozice == cil_pozice) // tadz by se ještě muselo vyřešit, že to nebude to nejlepší řešení... nutní projít přes počet kroků... jenže to by mohlo bežet taky do nekonečna - rekuze nešikovná
                {
                    Console.WriteLine(pocet_kroku);
                    return;
                }


                if (pocet_kroku == 0)
                {
                    aktualni_pozice = start_pozice;
                }
                else 
                {
                    aktualni_pozice = mozne_pole.Dequeue();
                }


                if (sachovnice[aktualni_pozice[0], aktualni_pozice[1]] > pocet_kroku)
                {
                    sachovnice[aktualni_pozice[0], aktualni_pozice[1]] = pocet_kroku;
                }


                int[] mozna_pozice = [0, 0];

                for (int i = 0; i < vektor_tahu.GetLength(0); i++) //menší než počet řádků ve vektor_tahu
                {
                    mozna_pozice[0] = aktualni_pozice[0] + vektor_tahu[i, 0];
                    mozna_pozice[1] = aktualni_pozice[1] + vektor_tahu[i, 1];

                    if (OverPole(mozna_pozice) == true) //žádná překážka nebo mimo mapu
                    {
                        pocet_kroku++;
                        mozne_pole.Enqueue(mozna_pozice);
                    }
                }
            }
        }

        public void Tahni_rekurze(int[] aktualni_pozice)
        {
            if (aktualni_pozice == cil_pozice && pocet_kroku_vetev > pocet_kroku && pocet_kroku != 0 && pocet_vetvi > 100)
            {
                pocet_kroku = pocet_kroku_vetev;
                Console.WriteLine(pocet_kroku);
                return;
            }
            else //yačnu to procházet znovu
            {
                pocet_vetvi++; //neelegantní, ale abych nejak zastavila rekurzi

                pocet_kroku = pocet_kroku_vetev;
                pocet_kroku_vetev = 0;

                aktualni_pozice = start_pozice;
                Tahni_rekurze(aktualni_pozice);
            }

             if (pocet_kroku == 0)
            {
                aktualni_pozice = start_pozice;
            }
            else
            {
                aktualni_pozice = mozne_pole.Dequeue();
            }


             int[] mozna_pozice = [0, 0];

             for (int i = 0; i < vektor_tahu.GetLength(0); i++) //menší než počet řádků ve vektor_tahu
             {
                  mozna_pozice[0] = aktualni_pozice[0] + vektor_tahu[i, 0];
                  mozna_pozice[1] = aktualni_pozice[1] + vektor_tahu[i, 1];

                  if (OverPole(mozna_pozice) == true && Navstiveno(mozna_pozice) == false) //žádná překážka nebo mimo mapu A NEBYLA JSEM TAM
                  {
                      pocet_kroku_vetev++;
                      navstivene_X.Add(mozna_pozice[0]);
                      navstivene_Y.Add(mozna_pozice[1]);
                      Tahni_rekurze(mozna_pozice);
                  }
             }
        }
    }
}